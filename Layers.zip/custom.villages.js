/*

This is a JavaScript file you can edit to add custom markers to the map.
uNmINeD does not overwrite this file during map generation.

Steps:

    1. Edit this file using Notepad or a code editor (do not use document editors like Microsoft Word)
    2. Change the line "isEnabled: false," to "isEnabled: true," to display the markers
    3. Change or remove the example markers
    4. Add your own markers

Marker format:

    {
        x: X coordinate of the marker (in Minecraft block units),
        z: Z coordinate of the marker (in Minecraft block units),
        image: marker image URL to display (in quotes),
        imageScale: scale of the image (e.g. 1 = display full size, 0.5 = display half size),
        imageAnchor: [0.5, 1] means the tip of the pin is at the center-bottom of the image (see OpenLayers documentation for more info),
        text: marker text do display (in quotes),
        textColor: text color in HTML/CSS format (in quotes),
        offsetX: horizontal pixel offset of the text,
        offsetY: vertical pixel offset of the text,
        font: text font in HTML/CSS format (in quotes),
    },

Things to keep in mind:

* There are opening and closing brackets for each marker "{" and "}"
* Property names are case sensitive (i.e. "textColor" is okay, "TextColor" is not)
* There is a comma (",") at the end of each line except the opening brackets ("{")

You can use https://mapmarker.io/editor to generate custom pin images.
Use the imageScale property if the pin image is too large.

*/
UnminedCustomVillages = {
    isEnabled: true,

    villages: [
        // Igloo
            // igloo 1
                {
                    x: -200,
                    z: -1176,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 2
                {
                    x: -456,
                    z: -968,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 3
                {
                    x: 5944,
                    z: -2504,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 4
                {
                    x: 5192,
                    z: -2392,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 5
                {
                    x: -4648,
                    z: -2248,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 6
                {
                    x: 5144,
                    z: -1896,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 7
                {
                    x: 4760,
                    z: -1720,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 8
                {
                    x: 4360,
                    z: -1336,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 9
                {
                    x: 3800,
                    z: -1336,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 10
                {
                    x: 3240,
                    z: -952,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 11
                {
                    x: 2760,
                    z: -824,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // igloo 12
                {
                    x: 2216,
                    z: -840,
                    image: "igloo.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },

        // Village 
            // village 1
                {
                    x: -378,
                    z: -967,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 2
                {
                    x: -1541,
                    z: -1258,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 3
                {
                    x: -1022,
                    z: -1963,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 4
                {
                    x: -1364,
                    z: -2100,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 5
                {
                    x: -1892,
                    z: 331,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 6
                {
                    x: 773,
                    z: 2957,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 7
                {
                    x: -2396,
                    z: -1908,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 8
                {
                    x: -2522,
                    z: -2453,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 9
                {
                    x: -3243,
                    z: -2603,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 10
                {
                    x: -3987,
                    z: -2548,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 11
                {
                    x: -299,
                    z: -2884,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 12
                {
                    x: -964,
                    z: -4190,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 13
                {
                    x: -1573,
                    z: -4172,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 14
                {
                    x: -2038,
                    z: -4745,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 15
                {
                    x: -218,
                    z: -4690,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 16
                {
                    x: 925,
                    z: -5755,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 17
                {
                    x: 1765,
                    z: -5172,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 18
                {
                    x: 3477,
                    z: -5947,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 19
                {
                    x: 4627,
                    z: -5605,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 20
                {
                    x: 5109,
                    z: -4555,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 21
                {
                    x: 3965,
                    z: -4140,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 22
                {
                    x: 4965,
                    z: -3627,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 23
                {
                    x: 4616,
                    z: -3101,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 24
                {
                    x: 2955,
                    z: -2996,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 25
                {
                    x: 2365,
                    z: -1419,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 26
                {
                    x: 5094,
                    z: 4109,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 27
                {
                    x: 4437,
                    z: 4093,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 28
                {
                    x: 5260,
                    z: 4604,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 29
                {
                    x: 5548,
                    z: 4710,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 30
                {
                    x: 3939,
                    z: 4971,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 31
                {
                    x: 3030,
                    z: 2501,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 32
                {
                    x: 733,
                    z: 2359,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 33
                {
                    x: 699,
                    z: 1941,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 34
                {
                    x: 220,
                    z: 2443,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 35
                {
                    x: -311,
                    z: 2300,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 36
                {
                    x: 764,
                    z: 3564,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 37
                {
                    x: 293,
                    z: 3996,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 38
                {
                    x: 211,
                    z: 4378,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 39
                {
                    x: -940,
                    z: 1813,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 40
                {
                    x: -1445,
                    z: 1908,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 41
                {
                    x: -2619,
                    z: 3996,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 42
                {
                    x: -1913,
                    z: 5771,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 43
                {
                    x: -3502,
                    z: 2440,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 44
                {
                    x: -3725,
                    z: 4910,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 45
                {
                    x: -4613,
                    z: 4630,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 46
                {
                    x: -5212,
                    z: 5005,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 47
                {
                    x: -4699,
                    z: 3829,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 48
                {
                    x: -4803,
                    z: 3507,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 49
                {
                    x: -4267,
                    z: 2948,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 50
                {
                    x: -3777,
                    z: 1837,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 51
                {
                    x: -5229,
                    z: -373,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 52
                {
                    x: -5750,
                    z: -1279,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 53
                {
                    x: -4345,
                    z: -3526,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 54
                {
                    x: -5291,
                    z: -4132,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 55
                {
                    x: -5211,
                    z: -5845,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 56
                {
                    x: 4998,
                    z: -2468,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 57
                {
                    x: 4473,
                    z: -2491,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 58
                {
                    x: 3946,
                    z: -2159,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 59
                {
                    x: 3986,
                    z: -1597,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 60
                {
                    x: 4457,
                    z: -2006,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 61
                {
                    x: 5059,
                    z: -1971,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 62
                {
                    x: 5543,
                    z: -2048,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 63
                {
                    x: 3399,
                    z: -1428,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 64
                {
                    x: 3473,
                    z: -463,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 65
                {
                    x: 2774,
                    z: -428,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 66
                {
                    x: 2387,
                    z: -865,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 67
                {
                    x: 2489,
                    z: -409,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 68
                {
                    x: 2342,
                    z: 35,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 69
                {
                    x: 2973,
                    z: 133,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 70
                {
                    x: 3341,
                    z: 222,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 71
                {
                    x: 2517,
                    z: -3108,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 72
                {
                    x: 1828,
                    z: -3115,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 73
                {
                    x: 2347,
                    z: -3679,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 74
                {
                    x: 5617,
                    z: 2868,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 75
                {
                    x: 5579,
                    z: 1239,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 76
                {
                    x: 4127,
                    z: 1265,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 77
                {
                    x: 4006,
                    z: 637,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 78
                {
                    x: 4532,
                    z: 654,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 79
                {
                    x: 4187,
                    z: 204,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 80
                {
                    x: 5603,
                    z: 294,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 81
                {
                    x: 5044,
                    z: 265,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 82
                {
                    x: 4487,
                    z: 246,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 83
                {
                    x: 5050,
                    z: 204,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 84
                {
                    x: 3868,
                    z: -340,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 85
                {
                    x: 4011,
                    z: -990,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 86
                {
                    x: 4644,
                    z: -1434,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
            // village 87
                {
                    x: 2954,
                    z: 4540,
                    image: "VillagerFace.png",
                    imageAnchor: [0.5, 1],
                    imageScale: 0.3,
                },
    // do not delete the following two closing brackets
    ]
};

